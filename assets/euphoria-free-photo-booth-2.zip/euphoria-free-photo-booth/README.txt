EUPHORIA 2026 — FREE BROWSER PHOTO BOOTH

WHAT IT DOES
- Static web page, no AI image API or per-image generation credits.
- Uses MediaPipe Selfie Segmentation in each visitor's browser.
- Composites the person over a stage scene cropped from the official Euphoria flyer.
- Exports a PNG locally in the browser.

PRIVACY
- The photo is not uploaded to a server by this app.
- The background-removal JavaScript/model is loaded from jsDelivr on first use.
- The photo is processed locally in the browser.

PUBLISH FOR FREE
1. Create a GitHub account and a new public repository.
2. Upload index.html and the assets folder (keep the folder structure).
3. In the repository, open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and / (root), then Save.
6. Wait for GitHub Pages to publish. Copy the public URL and share it.

No API key, payment method, or backend server is required. GitHub Pages is static hosting, but all free hosting providers have fair-use/traffic policies; this avoids AI generation quotas, not every possible hosting or bandwidth limit.

IMPORTANT
- This tool is a compositing photo booth, not generative AI. It does not invent new poses, clothes, or lighting on the person.
- Best results: one clearly visible person, good lighting, simple background, full or half-body portrait.
- The stage art is based on the supplied event flyer. Please ensure the organisers have permission to publish the flyer/logos online.
- The page uses MediaPipe Selfie Segmentation via jsDelivr. A first-time internet connection is required to load the model.
